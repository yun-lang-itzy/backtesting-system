def factor(context, window=60, skip=5):
    p = context.history('adjusted_close', window + skip + 1)
    return (p.iloc[-1-skip] / p.iloc[-1-skip-window] - 1).where(p.notna().all() & p.gt(0).all())
