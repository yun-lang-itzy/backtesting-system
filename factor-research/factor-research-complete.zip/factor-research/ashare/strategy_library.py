"""Local strategy documents. Saving/loading never executes user code."""
import json
import sqlite3
from contextlib import contextmanager, closing
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4


class StrategyLibrary:
    def __init__(self,root):
        self.root=Path(root)

    @contextmanager
    def connection(self):
        self.root.mkdir(parents=True,exist_ok=True)
        with closing(sqlite3.connect(self.root/'strategies.sqlite3',timeout=10)) as db, db:
            db.row_factory=sqlite3.Row
            db.execute('''CREATE TABLE IF NOT EXISTS strategies (
                id TEXT PRIMARY KEY, name TEXT NOT NULL, name_key TEXT NOT NULL,
                source TEXT NOT NULL, params TEXT NOT NULL, description TEXT NOT NULL,
                created_at TEXT NOT NULL, updated_at TEXT NOT NULL, deleted_at TEXT)''')
            db.execute('CREATE UNIQUE INDEX IF NOT EXISTS active_strategy_names ON strategies(name_key) WHERE deleted_at IS NULL')
            yield db

    def list(self,deleted=False):
        with self.connection() as db:
            return [self.decode(row) for row in db.execute('SELECT * FROM strategies WHERE deleted_at IS '+('NOT NULL' if deleted else 'NULL')+' ORDER BY updated_at DESC,id')]

    @staticmethod
    def decode(row):
        item=dict(row);item['params']=json.loads(item['params']);return item

    def get(self,identifier,deleted=False):
        with self.connection() as db:
            row=db.execute('SELECT * FROM strategies WHERE id=? AND deleted_at IS '+('NOT NULL' if deleted else 'NULL'),(identifier,)).fetchone()
            if row is None:raise ValueError('策略不存在，或已被删除，请刷新策略库')
            return self.decode(row)

    def save(self,name,source,params,description='',identifier=None):
        name=name.strip()
        if not name or len(name)>100:raise ValueError('策略名称须为1至100个字符')
        if not isinstance(source,str) or not source.strip():raise ValueError('策略代码不能为空')
        if not isinstance(params,dict):raise ValueError('策略参数须为JSON对象')
        encoded=json.dumps(params,ensure_ascii=False,allow_nan=False)
        now=datetime.now(timezone.utc).isoformat()
        with self.connection() as db:
            try:
                if identifier:
                    changed=db.execute('UPDATE strategies SET name=?,name_key=?,source=?,params=?,description=?,updated_at=? WHERE id=? AND deleted_at IS NULL',(name,name.casefold(),source,encoded,description,now,identifier)).rowcount
                    if not changed:raise ValueError('策略已不存在，无法更新')
                else:
                    identifier=uuid4().hex
                    db.execute('INSERT INTO strategies VALUES (?,?,?,?,?,?,?,?,NULL)',(identifier,name,name.casefold(),source,encoded,description,now,now))
            except sqlite3.IntegrityError as exc:
                raise ValueError('已有同名策略，请换名另存或使用“更新所选策略”') from exc
        return identifier

    def delete(self,identifier):
        with self.connection() as db:
            if not db.execute('UPDATE strategies SET deleted_at=? WHERE id=? AND deleted_at IS NULL',(datetime.now(timezone.utc).isoformat(),identifier)).rowcount:
                raise ValueError('策略已不存在')

    def restore(self,identifier):
        with self.connection() as db:
            try:
                if not db.execute('UPDATE strategies SET deleted_at=NULL,updated_at=? WHERE id=? AND deleted_at IS NOT NULL',(datetime.now(timezone.utc).isoformat(),identifier)).rowcount:
                    raise ValueError('回收站中不存在该策略')
            except sqlite3.IntegrityError as exc:
                raise ValueError('已有同名策略，请先重命名现有策略再恢复') from exc
