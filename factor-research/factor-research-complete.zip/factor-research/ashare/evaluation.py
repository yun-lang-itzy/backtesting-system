"""Reusable evaluation of archived accounts; never reruns or rewrites old trades."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from .data import sha256


def evaluate_strategy(path):
    path=Path(path)
    config=json.loads((path/'config.json').read_text())
    d=pd.read_csv(path/'daily.csv',parse_dates=['date']).set_index('date')
    initial=config['engine']['initial_cash']; eq=d.equity
    ret=eq/eq.shift().fillna(initial)-1
    dd=eq/eq.cummax().clip(lower=initial)-1
    # Duration counts observed sessions below a prior peak, including initial capital.
    duration=[]; count=0
    for x in dd:
        count=count+1 if x < -1e-12 else 0; duration.append(count)
    trough=dd.idxmin(); prior=eq.loc[:trough]; peak=prior.idxmax() if prior.max()>=initial else None
    peak_value=max(initial,prior.max())
    recovery=eq.loc[eq.index>trough]; recovery=recovery[recovery>=peak_value]
    exposure=pd.DataFrame({'actual_stock_weight':d.market_value/eq,'cash_weight':d.cash/eq,'drawdown':dd,'underwater_sessions':duration})
    exposure['target_stock_weight']=np.nan
    if (path/'targets.csv').exists():
        targets=pd.read_csv(path/'targets.csv',parse_dates=['date'])
        # A close decision becomes the intended target next session, not that same close.
        t=targets.set_index('date').target_weight
        union=t.index.union(d.index).sort_values()
        shifted=t.reindex(union).ffill().shift(1)
        exposure['target_stock_weight']=shifted.reindex(d.index)
    if config['engine'].get('terminal_mode','hold')!='hold' and exposure.target_stock_weight.notna().any():
        exposure.loc[exposure.index[-1],'target_stock_weight']=0.
    exposure['target_minus_actual']=exposure.target_stock_weight-exposure.actual_stock_weight
    metrics={'total_return':float(eq.iloc[-1]/initial-1),'max_drawdown':float(dd.min()),'drawdown_peak_date':str(peak.date()) if peak is not None else 'initial_capital', 'drawdown_trough_date':str(trough.date()),'recovery_date':str(recovery.index[0].date()) if len(recovery) else None,'longest_underwater_sessions':max(duration),'current_underwater_sessions':duration[-1],'average_stock_weight':float(exposure.actual_stock_weight.mean()),'average_target_stock_weight':float(exposure.target_stock_weight.mean()) if exposure.target_stock_weight.notna().any() else None,'average_target_gap':float(exposure.target_minus_actual.mean()) if exposure.target_minus_actual.notna().any() else None,'fees':float(d.fees.sum()),'slippage':float(d.slippage_cost.sum()),'final_stale_value':float(d.stale_value.iloc[-1])}
    orders=pd.read_csv(path/'orders.csv')
    settlement=orders.status.eq('hypothetical_settlement')
    normal=orders[~settlement].copy()
    normal['fill_ratio']=np.where(normal.requested_units>0,(normal.filled_units/normal.requested_units).clip(0,1),0.)
    normal['unfilled_at_signal_value']=normal.requested_value_at_signal*(1-normal.fill_ratio)
    reasons=normal.groupby(['side','status']).agg(orders=('status','size'),requested_value=('requested_value_at_signal','sum'),unfilled_at_signal_value=('unfilled_at_signal_value','sum')).reset_index()
    total=normal.requested_value_at_signal.sum()
    metrics['normal_value_fill_ratio']=float(1-normal.unfilled_at_signal_value.sum()/total) if total>0 else None
    metrics['hypothetical_settlement_value']=float(orders.loc[settlement,'filled_notional'].sum())
    metrics['final_stock_value']=float(d.market_value.iloc[-1])
    for file,column,prefix in [('comparison.csv','equal_weight_nav','equal_weight'),('benchmark.csv','benchmark_nav','benchmark')]:
        if not (path/file).exists(): continue
        b=pd.read_csv(path/file)
        if column not in b: continue
        br=b[column].pct_change(fill_method=None);br.iloc[0]=b[column].iloc[0]-1
        br.index=pd.to_datetime(b.iloc[:,0]); br=br.reindex(d.index)
        if br.isna().any(): continue
        active=ret-br; tracking=active.std()*np.sqrt(252)
        metrics[prefix+'_tracking_error']=float(tracking)
        metrics[prefix+'_information_ratio']=float(active.mean()*252/tracking) if tracking>0 else None
        metrics[prefix+'_relative_total_return']=float((eq.iloc[-1]/initial)/b[column].iloc[-1]-1)
    if (path/'summary.json').exists():
        base=json.loads((path/'summary.json').read_text())
        metrics.update({k:base[k] for k in ['cagr','annual_volatility','sharpe_rf_zero','annual_one_way_turnover','trades'] if k in base})
    return metrics,exposure,reasons


def write_evaluation(path,out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    metrics,exposure,reasons=evaluate_strategy(path)
    (out/'strategy_evaluation.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2,allow_nan=False))
    exposure.to_csv(out/'exposure_evaluation.csv')
    reasons.to_csv(out/'execution_reasons.csv',index=False)
    (out/'evaluation_provenance.json').write_text(json.dumps({'source_run':Path(path).name,'inputs':{name:sha256(Path(path)/name) for name in ['config.json','daily.csv','orders.csv']},'evaluator_sha256':sha256(Path(__file__))},indent=2))
    text='\n## 策略评价\n\n'
    labels={'longest_underwater_sessions':'最长回撤持续观察日','current_underwater_sessions':'期末回撤持续观察日','drawdown_peak_date':'最大回撤峰值日期','drawdown_trough_date':'最大回撤谷值日期','recovery_date':'最大回撤恢复日期（空为未恢复）','average_stock_weight':'平均实际股票仓位','average_target_stock_weight':'平均目标股票仓位','average_target_gap':'平均目标减实际仓位','normal_value_fill_ratio':'正常订单信号金额加权成交比例','hypothetical_settlement_value':'假设结算金额','final_stock_value':'期末股票市值'}
    for key,label in labels.items(): text+=f'- {label}：{metrics[key]}\n'
    text+='\n目标仓位由实际策略回调记录，延至下一观察日对齐；选择期末退出时最后一日目标为零；旧运行缺少目标日志则留空，不从模板参数猜测。目标与实际差异并非单一原因的因果归因。\n\nexecution_reasons.csv按引擎原始互斥结果记录受阻订单；partial_capacity_or_cash仍是容量/现金合并原因，不假装已经拆分。假设结算单独列示，不计入正常订单成交率。主动收益=策略日收益减对照日收益，跟踪误差按252日年化。\n'
    (out/'strategy_evaluation.md').write_text(text)
    return metrics,exposure,reasons


def compare_runs(paths):
    records=[]; contracts=[]
    for path in map(Path,paths):
        status=json.loads((path/'status.json').read_text())
        if status.get('status')!='complete': raise ValueError('仅比较完整运行')
        cfg=json.loads((path/'config.json').read_text()); audit=json.loads((path/'data_audit.json').read_text())
        m,_,_=evaluate_strategy(path)
        records.append({'run':path.name,**m})
        contracts.append({'run':path.name,'start':cfg['start'],'end':cfg['end'],'symbols':sorted(cfg.get('symbols',[])), 'engine':cfg.get('engine'), 'unknown_status_policy':cfg.get('unknown_status_policy','allow'),'data_hashes':{k:v.get('sha256') for k,v in audit.items() if isinstance(v,dict) and 'sha256' in v},'exclusions_sha256':audit.get('exclusions_sha256'),'source_hashes':audit.get('source_hashes'), 'benchmark_sha256':sha256(path/'benchmark_input.csv') if (path/'benchmark_input.csv').exists() else None})
    differences=[]
    if contracts:
        for key in contracts[0]:
            if key=='run': continue
            values=[json.dumps(c[key],sort_keys=True) for c in contracts]
            if len(set(values))>1: differences.append(key)
        # Missing evidence is not evidence that conditions match.
        for key in ['data_hashes','source_hashes']:
            if any(not c[key] for c in contracts): differences.append(key+':missing')
    return pd.DataFrame(records),differences,contracts
