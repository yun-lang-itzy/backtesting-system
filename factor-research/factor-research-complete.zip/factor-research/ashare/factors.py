"""Point-in-time factor research. Forward labels never enter the factor context."""
from pathlib import Path
from datetime import datetime
from uuid import uuid4
import json
import traceback
import numpy as np
import pandas as pd
from .data import load_data, sha256
from .universe import StatusFilter

TEMPLATES = {
    '中期动量': ('momentum',60,5,True),
    '短期反转': ('momentum',5,0,False),
    '低波动': ('volatility',60,0,False),
    '成交额': ('liquidity',20,0,True),
    '趋势强度': ('trend',120,0,True),
}

def template_source(kind):
    expressions = {
        'momentum': "p = context.history('adjusted_close', window + skip + 1)\n    return (p.iloc[-1-skip] / p.iloc[-1-skip-window] - 1).where(p.notna().all() & p.gt(0).all())",
        'volatility': "p = context.history('adjusted_close', window + 1)\n    return p.pct_change(fill_method=None).iloc[1:].std().where(p.notna().all() & p.gt(0).all())",
        'liquidity': "return context.history('amt', window).mean()",
        'trend': "p = context.history('adjusted_close', window)\n    return (p.iloc[-1] / p.mean() - 1).where(p.notna().all() & p.gt(0).all())",
    }
    return 'def factor(context, window=60, skip=5):\n    ' + expressions[kind] + '\n'

class FactorContext:
    def __init__(self, data, index, status):
        self._past = {k:v.iloc[:index+1] for k,v in data.items()}
        self.date = data['close'].index[index]
        self.symbols = tuple(data['close'].columns)
        self.security_status = status.to_dict()

    def history(self, field, bars=20):
        if not isinstance(bars,int) or bars < 1: raise ValueError('窗口必须为正整数')
        if field == 'adjusted_close':
            result = self._past['close'].tail(bars)*self._past['cumadj'].tail(bars)
        elif field in self._past: result = self._past[field].tail(bars)
        else: raise ValueError('未知字段: '+field)
        if len(result)<bars: raise ValueError('因子历史不足：请增加预热数据或推迟开始日期')
        return result.copy()

def evaluate(data, settings, source, status_filter=None, progress=None):
    status_filter = status_filter or StatusFilter(unknown_policy=settings.get('unknown_status_policy','block'))
    dates, symbols = data['close'].index, data['close'].columns
    start,end=pd.Timestamp(settings['start']),pd.Timestamp(settings['end'])
    horizons=settings.get('horizons',[5,20,60]); groups=settings.get('groups',5)
    step=settings.get('step',5); min_adv=float(settings.get('min_adv',50_000_000))
    if not horizons or any(type(h)!=int or h<1 for h in horizons) or len(set(horizons))!=len(horizons): raise ValueError('收益期限须为不重复的正整数')
    if type(groups)!=int or not 2<=groups<=20 or type(step)!=int or step<1: raise ValueError('分组2至20，采样间隔为正整数')
    if not np.isfinite(min_adv) or min_adv<0 or start>=end: raise ValueError('日期或流动性门槛无效')
    scope={}; exec(compile(source,'factor.py','exec'),scope)
    fn=scope.get('factor')
    if not callable(fn): raise ValueError('须定义 factor(context, **params)')
    indices=np.flatnonzero((dates>=start)&(dates<=end))[::step]
    if not len(indices): raise ValueError('区间没有数据')
    boundaries=[]
    if settings.get('split',False):
        a,b=pd.Timestamp(settings['train_end']),pd.Timestamp(settings['validation_end'])
        if not start<=a<b<end: raise ValueError('时间划分必须满足开始≤训练结束<验证结束<结束')
        boundaries=[a,b]
    adjopen=data['open']*data['cumadj']; adjclose=data['close']*data['cumadj']
    adv=data['amt'].rolling(20,min_periods=20).mean()
    positive_amt=data['amt'].gt(0).rolling(20,min_periods=20).sum().eq(20)
    coverage=[]; scores=[]; observations=[]; previous=None; previous_top=None
    for number,i in enumerate(indices):
        date=dates[i]; state=status_filter.at(date,symbols)
        segment=('train' if date<=boundaries[0] else 'validation' if date<=boundaries[1] else 'test') if boundaries else 'all'
        segment_end=({'train':boundaries[0],'validation':boundaries[1],'test':end}[segment]) if boundaries else end
        raw=fn(FactorContext(data,i,state),**settings.get('params',{}))
        if not isinstance(raw,pd.Series) or not raw.index.is_unique or not raw.index.isin(symbols).all(): raise ValueError('因子须返回以股票代码为唯一索引的Series，不允许未知代码')
        raw=pd.to_numeric(raw,errors='raise').reindex(symbols).replace([np.inf,-np.inf],np.nan)
        eligible=~status_filter.blocked(state) & adv.iloc[i].ge(min_adv) & positive_amt.iloc[i] & adjclose.iloc[i].gt(0)
        f=raw[eligible & raw.notna()].sort_index()
        # Ties stay in the same group: constant factors must not create fake rankings.
        oriented=f if settings.get('higher_is_better',True) else -f
        buckets=np.ceil(oriented.rank(method='average',pct=True)*groups).clip(1,groups).astype(int)
        top=set(buckets[buckets==groups].index)
        rank_stability=np.nan
        if previous is not None:
            common=previous.index.intersection(oriented.index)
            if len(common)>1 and previous.loc[common].nunique()>1 and oriented.loc[common].nunique()>1: rank_stability=previous.loc[common].rank().corr(oriented.loc[common].rank())
        turnover=1-len(top & previous_top)/len(previous_top) if previous_top else np.nan
        coverage.append(dict(date=date,segment=segment,pool=len(symbols),unknown=int((state=='UNKNOWN').sum()),status_blocked=int(status_filter.blocked(state).sum()),eligible_before_factor=int(eligible.sum()),factor_valid=len(f),rank_stability=rank_stability,top_membership_turnover=turnover))
        scores.append(pd.DataFrame({'date':date,'symbol':f.index,'factor':f.values,'group':buckets.reindex(f.index).values,'segment':segment}))
        previous,previous_top=oriented,top
        for h in horizons:
            j=i+h  # buy open i+1, sell close i+h: h observed sessions
            if j>=len(dates) or dates[j]>segment_end:
                observations.append(dict(date=date,segment=segment,horizon=h,group=0,n_signal=len(f),n_valid=0,label_status='purged_boundary',rank_ic=np.nan,mean_return=np.nan))
                continue
            forward=(adjclose.iloc[j]/adjopen.iloc[i+1]-1).reindex(f.index)
            valid=forward.notna() & np.isfinite(forward) & adjopen.iloc[i+1].reindex(f.index).gt(0) & adjclose.iloc[j].reindex(f.index).gt(0)
            forward=forward.where(valid)
            ic=oriented[valid].rank().corr(forward[valid].rank()) if valid.sum()>1 and oriented[valid].nunique()>1 and forward[valid].nunique()>1 else np.nan
            for g in [0]+list(range(1,groups+1)):
                mask=pd.Series(True,index=f.index) if g==0 else buckets.eq(g)
                values=forward[mask]
                observations.append(dict(date=date,segment=segment,horizon=h,group=g,n_signal=int(mask.sum()),n_valid=int(values.notna().sum()),label_status='evaluated',rank_ic=ic if g==0 else np.nan,mean_return=values.mean()))
        if progress: progress('因子评价 '+str(date)[:10],.1+.75*(number+1)/len(indices))
    return {'coverage':pd.DataFrame(coverage),'scores':pd.concat(scores,ignore_index=True),'observations':pd.DataFrame(observations)}

def summarize_factor(observations):
    rows=[]
    for (segment,h),f in observations.groupby(['segment','horizon']):
        all_rows=f[(f.group==0)&(f.label_status=='evaluated')]; ic=all_rows.rank_ic.dropna()
        grouped=f[(f.group>0)&(f.label_status=='evaluated')].groupby('group').mean_return.mean()
        rows.append(dict(segment=segment,horizon=h,ic_mean=ic.mean(),ic_std=ic.std(),ic_ir_unannualized=ic.mean()/ic.std() if ic.std()>0 else np.nan,ic_positive_fraction=(ic>0).mean() if len(ic) else np.nan,ic_dates=len(ic),label_coverage=all_rows.n_valid.sum()/all_rows.n_signal.sum() if all_rows.n_signal.sum() else np.nan,group_monotonicity=grouped.index.to_series().corr(grouped,method='pearson') if len(grouped)>1 and grouped.std()>0 else np.nan,purged_dates=int(((f.group==0)&(f.label_status=='purged_boundary')).sum())))
    return pd.DataFrame(rows)

def run_factor(settings,source,root,progress=None):
    out=Path(root)/(datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+uuid4().hex[:8]); out.mkdir(parents=True)
    (out/'config.json').write_text(json.dumps(settings,ensure_ascii=False,indent=2))
    (out/'factor.py').write_text(source)
    (out/'status.json').write_text('{"status":"running"}')
    if progress: progress('读取因子数据',.02,out)
    try:
        data,audit=load_data(Path(settings['data']))
        if settings.get('symbols'): data={k:v.loc[:,settings['symbols']] for k,v in data.items()}
        status=StatusFilter(settings.get('exclusions') or None,settings.get('unknown_status_policy','block'))
        if settings.get('exclusions'):
            import shutil
            shutil.copyfile(settings['exclusions'],out/'exclusions.csv')
            audit['exclusions_sha256']=sha256(out/'exclusions.csv')
        import platform
        audit['runtime']={'python':platform.python_version(),'pandas':pd.__version__,'numpy':np.__version__}
        audit['source_hashes']={p.name:sha256(p) for p in Path(__file__).parent.glob('*.py')}
        audit['factor_sha256']=sha256(out/'factor.py'); audit['evaluator_sha256']=sha256(Path(__file__))
        (out/'data_audit.json').write_text(json.dumps(audit,indent=2))
        frames=evaluate(data,settings,source,status,(lambda stage,f:progress(stage,.05+.5*f)) if progress else None)
        for name,f in frames.items(): f.to_csv(out/(name+'.csv'),index=False)
        if frames['coverage'].factor_valid.sum()==0: raise ValueError('没有有效因子样本：检查历史状态覆盖、流动性和因子窗口')
        summary=summarize_factor(frames['observations']); summary.to_csv(out/'factor_summary.csv',index=False)
        obs=frames['observations']; obs=obs[obs.label_status=='evaluated'].copy()
        grouped=obs.pivot(index=['date','segment','horizon'],columns='group',values='mean_return')
        excess=pd.DataFrame(index=grouped.index)
        excess['pool_equal_return']=grouped.get(0,np.nan)
        excess['top_return']=grouped.get(settings.get('groups',5),np.nan)
        excess['bottom_return']=grouped.get(1,np.nan)
        excess['top_minus_pool']=excess.top_return-excess.pool_equal_return
        excess['top_minus_bottom_research']=excess.top_return-excess.bottom_return
        excess.to_csv(out/'group_comparison.csv')
        obs['year']=pd.to_datetime(obs.date).dt.year
        obs.groupby(['year','horizon','group']).agg(mean_return=('mean_return','mean'),dates=('mean_return','count'),mean_ic=('rank_ic','mean')).to_csv(out/'annual_factor.csv')
        export_factor(out,settings,frames,summary)
        from .factor_diagnostics import advanced_diagnostics, export_diagnostics
        from .factor_execution import run_group_execution
        advanced_diagnostics(data,settings,frames,status,out,progress)
        run_group_execution(data,settings,source,status,out,audit,progress)
        if settings.get('diagnostics',{}).get('enabled') or settings.get('execution',{}).get('enabled'):
            export_diagnostics(out)
        (out/'status.json').write_text('{"status":"complete"}')
        return out,frames,summary
    except Exception:
        (out/'status.json').write_text('{"status":"failed"}')
        (out/'error.txt').write_text(traceback.format_exc()); raise

def markdown_table(frame):
    def cell(value):
        if pd.isna(value):return '—'
        if isinstance(value,(float,np.floating)):return f'{value:.6g}'
        return str(value).replace('|','\\|').replace('\n',' ')
    lines=['| '+' | '.join(map(str,frame.columns))+' |','| '+' | '.join(['---']*len(frame.columns))+' |']
    lines += ['| '+' | '.join(cell(v) for v in row)+' |' for row in frame.itertuples(index=False,name=None)]
    return '\n'.join(lines)+'\n'


def export_factor(out,settings,frames,summary):
    import os,tempfile,html,base64
    os.environ.setdefault('MPLCONFIGDIR',str(Path(tempfile.gettempdir())/'ceyan-mpl'))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    o=frames['observations']; valid=o[o.label_status=='evaluated']
    fig,axes=plt.subplots(4,1,figsize=(11,14))
    for h,f in valid[valid.group==0].groupby('horizon'):
        axes[0].plot(f.date,f.rank_ic.rolling(20,min_periods=1).mean(),label=f'{h} sessions')
    axes[0].set_title('Rank IC | trailing 20 sampled dates');axes[0].legend()
    table=valid[valid.group>0].groupby(['group','horizon']).mean_return.mean().unstack()
    if not table.empty: table.plot.bar(ax=axes[1])
    axes[1].set_title('Mean forward return by group (not portfolio NAV)')
    ic=valid[valid.group==0].groupby('horizon').rank_ic.mean()
    axes[2].plot(ic.index,ic.values,marker='o');axes[2].set(title='Factor decay',xlabel='Holding sessions',ylabel='Mean Rank IC')
    for h,f in valid[valid.group==0].groupby('horizon'):
        axes[3].hist(f.rank_ic.dropna(),bins=20,alpha=.4,label=str(h))
    axes[3].set_title('Rank IC distribution');axes[3].legend()
    fig.tight_layout();fig.savefig(out/'factor_charts.png',dpi=140);plt.close(fig)
    text='''# 策演 · 因子评价\n\n本报告为信号研究，不含交易成本、涨跌停、T+1和成交容量。\n\n- T日收盘评分，T+1开盘至T+h收盘的复权收益；h为观察日数。\n- 高组为优先方向；先按当日已知状态及历史20日成交额筛选。未知状态单独披露。\n- 分组在收益标签可得性筛选之前固定；缺失标签不填零、不前向填充，披露有效样本，仍可能存在缺失样本偏差。\n- 同分股票不拆组，因此可能出现空组；常数因子不计算有效IC。\n- 分组收益为各信号日远期收益均值，不能将重叠期限直接复利成净值。\n- group_comparison.csv包含顶组减同池等权与顶组减底组的同期收益差；后者只是研究差值，不假设股票可做空。\n- IC IR为均值/标准差，未年化，不提供假设样本独立的显著性。\n- 时间分区按信号日期；退出日期超过分区末日的标签剔除。已有历史均按已观察处理，不自动选优。\n- 排名稳定性基于相邻采样日共同股票；顶组成员换手为上期顶组流失比例，不是交易换手。\n- 缺少历史行业和市值，未进行行业/市值中性化。\n\n## 统计摘要\n\n'''
    text+=markdown_table(summary)+'\n\n![因子图表](factor_charts.png)\n'
    (out/'report.md').write_text(text)
    encoded=base64.b64encode((out/'factor_charts.png').read_bytes()).decode()
    (out/'report.html').write_text('<meta charset="utf-8"><title>策演·因子评价</title><body style="max-width:1100px;margin:40px auto;font:16px system-ui"><pre style="white-space:pre-wrap">'+html.escape(text)+'</pre><img style="width:100%" src="data:image/png;base64,'+encoded+'"></body>')
