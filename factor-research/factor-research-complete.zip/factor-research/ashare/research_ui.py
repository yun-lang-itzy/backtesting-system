"""Research pages reuse archived run formats and background job management."""
import io
import json
import zipfile
from pathlib import Path
from datetime import datetime
import pandas as pd
import streamlit as st
from .jobs import launch,read_state,cancel
from .factors import TEMPLATES,template_source
from .evaluation import write_evaluation,compare_runs


def completed(root):
    return [p.parent for p in sorted(Path(root).glob('*/status.json'),reverse=True) if json.loads(p.read_text()).get('status')=='complete']


def download(out,label):
    key='archive_'+str(out)
    if st.button('准备'+label,key=key+'_prepare'):
        archive=io.BytesIO()
        with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
            for p in Path(out).rglob('*'):
                if p.is_file(): z.write(p,str(p.relative_to(out)))
        st.session_state[key]=archive.getvalue()
    if key in st.session_state:
        st.download_button(label,st.session_state[key],file_name=Path(out).name+'.zip',key=key+'_download')



@st.fragment(run_every=1)
def factor_progress():
    job=st.session_state.get('factor_job')
    if not job:return
    state=read_state(job)
    st.progress(state.get('progress',0),text=state.get('stage',''))
    if state['status']=='running':
        if st.button('取消因子评价'):cancel(job);st.rerun()
    elif state['status']=='complete':
        st.success('因子评价完成')
        if st.button('刷新因子结果'):st.rerun()
    else:st.warning(state.get('stage','未完成'))


def factor_page(root,default_data):
    st.header('因子研究')
    st.caption('评估信号排序能力；分组收益不含成交约束，不是可交易账户净值。')
    with st.expander('因子数据与评价口径',expanded=True):
        data=st.text_input('因子数据目录',default_data,key='research_49')
        cols=st.columns(2)
        start=cols[0].date_input('信号开始日期',pd.Timestamp('2025-01-02'))
        end=cols[1].date_input('信号及标签截止日期',pd.Timestamp('2026-09-30'))
        pool=st.text_area('因子股票池（空为全部，逗号分隔）',key='research_53')
        exclusions=st.text_input('因子历史状态CSV路径',key='research_54')
        policy=st.selectbox('因子未知状态处理',['block','allow'],format_func=lambda x:'排除未知' if x=='block' else '允许未知并披露',key='research_55')
        adv=st.number_input('因子20日成交额门槛（万元）',min_value=0.,value=5000.,key='research_56')
        horizons=st.multiselect('未来收益期限（观察日）',[1,5,10,20,60],default=[5,20,60],key='research_57')
        groups=st.number_input('分组数',min_value=2,max_value=20,value=5,key='research_58')
        step=st.number_input('采样间隔（观察日，1为逐日）',min_value=1,value=5,key='research_59')
        split=st.checkbox('因子训练 / 验证 / 测试分区',key='research_60')
        a=st.date_input('因子训练结束',pd.Timestamp('2025-06-30'),key='research_61')
        b=st.date_input('因子验证结束',pd.Timestamp('2025-12-31'),key='research_62')
    name=st.selectbox('因子起点',list(TEMPLATES),key='research_63')
    kind,window,skip,direction=TEMPLATES[name]
    if 'factor_source' not in st.session_state:st.session_state.factor_source=template_source('momentum')
    if st.button('载入因子模板'):st.session_state.factor_source=template_source(kind)
    source=st.text_area('Python 因子代码',key='factor_source',height=260)
    st.download_button('下载因子代码',source,file_name='factor.py')
    params=st.text_area('因子参数 JSON',json.dumps({'window':window,'skip':skip}),key='factor_params_'+name)
    higher=st.checkbox('高值优先（低波动、反转请取消）',value=direction,key='direction_'+name)
    st.caption('须返回以代码为索引的pandas Series；context.history只提供当日及过去数据。代码在本机以当前用户权限执行，不是安全沙箱。选择模板后需点击载入，方向与参数独立保存。')
    with st.expander('扩展因子评价',expanded=True):
        diagnostics_enabled=st.checkbox('启用相关性、增量、分层及稳健性诊断',value=True,key='research_advanced')
        controls=st.multiselect('控制 / 对照因子',list(TEMPLATES),default=[x for x in ['中期动量','低波动','成交额','趋势强度'] if x!=name],key='research_controls')
        st.caption('与自身相同的因子会显示冗余、剩余信号为空；要检验新增信息，请选择其他控制因子。')
        delays=st.multiselect('额外延迟入场日数',[0,1,2,3,5,10],default=[0,1,2,5],key='research_delays')
        variants=st.text_area('因子参数稳定性 JSON 列表','[]',help='例如 [{"window":40},{"window":80}]，覆盖当前因子参数；不自动选优。',key='research_variants')
        block=st.number_input('重采样时间块长度（采样点数）',min_value=1,value=5,key='research_block')
        repeats=st.number_input('时间块重采样次数',min_value=100,max_value=10000,value=1000,step=100,key='research_repeats')
        note=st.text_area('研究目的与参数尝试记录',help='历史数据均按已观察处理；记录调整原因，不将重复使用的测试期称为未见样本。',key='research_note')
    with st.expander('分组组合 · 成交约束验证',expanded=False):
        execution_enabled=st.checkbox('独立回测分组组合和同池等权',value=False,key='research_execute')
        execution_groups=st.multiselect('执行分组（高组为优先方向）',list(range(1,int(groups)+1)),default=[1,int(groups)],key='research_execution_groups')
        ec=st.number_input('分组组合初始资金（元）',min_value=1.,value=1_000_000_000.,key='research_exec_capital')
        ef=st.number_input('分组佣金单边（bps）',min_value=0.,value=1.,key='research_exec_fee')
        et=st.number_input('分组卖出税费（bps）',min_value=0.,value=5.,key='research_exec_tax')
        es=st.number_input('分组滑点（bps）',min_value=0.,value=5.,key='research_exec_slip')
        ep=st.number_input('分组历史成交额参与率',min_value=.00001,max_value=1.,value=.001,format='%.5f',key='research_exec_participation')
        ei=st.number_input('分组目标仓位（%）',min_value=.01,max_value=100.,value=95.,key='research_exec_investment')
        ew=st.number_input('分组单股上限（%）',min_value=.01,max_value=100.,value=5.,key='research_exec_weight')
        terminal=st.selectbox('分组结束方式',['hold','liquidate','settle'],format_func=lambda x:{'hold':'保留持仓','liquidate':'尝试清仓','settle':'剩余持仓假设结算'}[x],key='research_exec_terminal')
        st.caption('独立资金、周度调仓、前日信号首日必须成交；首日全受阻则记录情景失败。同池等权也只覆盖主因子有效股票。成交假设沿用引擎，与不含成本的h日信号收益不可直接相减。')
    if st.button('运行因子评价',type='primary'):
        try:
            args=json.loads(params)
            if not isinstance(args,dict): raise ValueError('因子参数须为JSON对象')
            if not horizons:raise ValueError('至少选择一个收益期限')
            if policy=='block' and not exclusions:raise ValueError('排除未知时必须提供含NORMAL记录的状态数据；否则没有可评价股票')
            if st.session_state.get('factor_job') and read_state(st.session_state.factor_job)['status']=='running':raise ValueError('已有因子任务运行，请等待或取消')
            settings=dict(data=data,start=str(start),end=str(end),exclusions=exclusions,unknown_status_policy=policy,symbols=[s.strip() for s in pool.replace('\n',',').split(',') if s.strip()],min_adv=adv*10000,horizons=horizons,groups=int(groups),step=int(step),split=split,train_end=str(a),validation_end=str(b),params=args,higher_is_better=higher)
            settings['diagnostics']=dict(enabled=diagnostics_enabled,controls=controls,delays=delays,parameter_sets=json.loads(variants),block_length=int(block),bootstrap_repeats=int(repeats),note=note)
            settings['execution']=dict(enabled=execution_enabled,groups=execution_groups,investment=ei/100,max_weight=ew/100,engine=dict(initial_cash=ec,fee_bps=ef,sell_extra_bps=et,slippage_bps=es,participation=ep,terminal_mode=terminal))
            st.session_state.factor_job=launch(settings,source,root,kind='factor')
        except Exception as e:st.error(str(e))
    factor_progress()
    paths=completed(root/'factor_runs')
    if not paths:return
    out=st.selectbox('因子研究记录',paths,format_func=lambda p:p.name,key='research_85')
    st.dataframe(pd.read_csv(out/'factor_summary.csv'),use_container_width=True)
    st.image(str(out/'factor_charts.png'))
    for label,file in [('样本覆盖与换手','coverage.csv'),('年度表现','annual_factor.csv'),('分组及等权对比','group_comparison.csv')]:
        with st.expander(label):st.dataframe(pd.read_csv(out/file),use_container_width=True)
    advanced_files=[('因子相关性','factor_correlation_summary.csv'),('增量信息','incremental_summary.csv'),('环境与股票分层','strata_summary.csv'),('置信区间','confidence_intervals.csv'),('延迟敏感性','delay_summary.csv'),('参数稳定性','parameter_stability.csv'),('异常值诊断','robustness_daily.csv'),('极端贡献','influence_daily.csv'),('执行后组合表现','factor_execution_summary.csv')]
    for title,file in advanced_files:
        if (out/file).exists():
            with st.expander(title):st.dataframe(pd.read_csv(out/file),use_container_width=True)
    if (out/'factor_execution_summary.csv').exists():
        failures=pd.read_csv(out/'factor_execution_summary.csv')
        if (failures.status=='failed').any():st.warning('部分执行情景失败，详情见执行后组合表现；不得视为零收益或成功清仓。')
    for file in ['factor_correlation.png','factor_intervals.png','factor_stability.png','factor_execution.png']:
        if (out/file).exists():
            st.image(str(out/file))
            if file=='factor_correlation.png':
                names=sorted(pd.read_csv(out/'factor_correlation_summary.csv').factor_a.unique())
                st.caption('相关性图例：'+', '.join(f'F{i}={name}' for i,name in enumerate(names)))
    if (out/'factor_attempts.json').exists():
        with st.expander('全部参数尝试（含失败）'):st.json(json.loads((out/'factor_attempts.json').read_text()))
    with st.expander('研究口径与完整配置'):

        st.markdown((out/'report.md').read_text().split('![因子图表]')[0]);
        if '## 扩展评价口径与限制' in (out/'report.md').read_text():st.markdown('## 扩展评价口径与限制'+(out/'report.md').read_text().split('## 扩展评价口径与限制')[1].split('![')[0])
        st.json(json.loads((out/'config.json').read_text()))
    st.download_button('下载因子HTML报告',(out/'report.html').read_bytes(),file_name='factor_report.html')
    download(out,'下载因子完整研究包')


def strategy_page(root):
    st.header('策略评价')
    paths=completed(root/'runs')
    if not paths:st.info('先完成一次策略回测。');return
    path=st.selectbox('选择待评价运行',paths,format_func=lambda p:p.name,key='research_100')
    st.caption('读取已有账户与订单，生成独立评价文件，不改写原始回测报告。旧运行无目标仓位日志时保持未知。')
    if st.button('生成 / 更新评价'):
        try:write_evaluation(path,root/'evaluations'/path.name)
        except Exception as e:st.error(str(e))
    out=root/'evaluations'/path.name
    if not (out/'strategy_evaluation.json').exists():return
    m=json.loads((out/'strategy_evaluation.json').read_text())
    cols=st.columns(3)
    cols[0].metric('平均股票仓位',f'{m["average_stock_weight"]:.2%}')
    cols[1].metric('最长回撤持续',f'{m["longest_underwater_sessions"]} 个观察日')
    cols[2].metric('假设结算金额',f'{m["hypothetical_settlement_value"]:,.2f}')
    exposure=pd.read_csv(out/'exposure_evaluation.csv',parse_dates=['date']).set_index('date')
    st.line_chart(exposure[['actual_stock_weight','target_stock_weight']])
    st.line_chart(exposure[['drawdown']])
    st.dataframe(pd.read_csv(out/'execution_reasons.csv'),use_container_width=True)
    st.markdown((out/'strategy_evaluation.md').read_text());st.json(m)
    for file in ['security_contributions.csv','unresolved_holdings.csv','sensitivity.csv','validation.csv','comparison_metrics.csv']:
        if (path/file).exists():
            with st.expander(file):st.dataframe(pd.read_csv(path/file),use_container_width=True)
    download(out,'下载策略评价包')


def comparison_page(root):
    st.header('实验对比')
    paths=completed(root/'runs')
    choices=st.multiselect('选择历史运行（至少两个）',paths,format_func=lambda p:p.name,key='research_126')
    st.caption('按相同日历区间、数据版本、股票池、ST政策、执行配置和引擎代码校验。参数与策略可以不同；不一致的运行仅作情景对照，不给胜负排名。成本/参数重跑与时间验证仍在策略开发页配置。')
    if len(choices)<2:return
    try:table,differences,contracts=compare_runs(choices)
    except Exception as e:st.error(str(e));return
    if differences:st.warning('口径不一致或证据缺失：'+', '.join(differences))
    else:st.success('已记录的比较口径一致。')
    st.dataframe(table,use_container_width=True)
    curves={}
    for path in choices:
        d=pd.read_csv(path/'daily.csv',parse_dates=['date']).set_index('date')
        initial=json.loads((path/'config.json').read_text())['engine']['initial_cash']
        curves[path.name]=d.equity/initial
    st.line_chart(pd.DataFrame(curves))
    note=st.text_area('研究记录（例如此次参数调整原因、测试期是否参与调参）',key='research_140')
    if st.button('保存本次对比'):
        from uuid import uuid4
        out=root/'comparisons'/(datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+uuid4().hex[:8]);out.mkdir(parents=True)
        table.to_csv(out/'comparison.csv',index=False)
        (out/'manifest.json').write_text(json.dumps({'contracts':contracts,'mismatches':differences,'note':note,'historical_data_already_observed':True},ensure_ascii=False,indent=2))
        st.session_state.comparison_export=str(out)
    if st.session_state.get('comparison_export'):download(st.session_state.comparison_export,'下载已保存的实验对比')
