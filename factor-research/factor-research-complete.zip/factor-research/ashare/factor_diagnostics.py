"""Historical diagnostics, not causal estimates or an automatic factor selector."""
import json
import math
from pathlib import Path
import numpy as np
import pandas as pd
from .factors import FactorContext, TEMPLATES, template_source, evaluate, summarize_factor, markdown_table


def correlation(a,b,rank=True):
    f=pd.concat([a,b],axis=1).replace([np.inf,-np.inf],np.nan).dropna()
    if len(f)<3 or f.iloc[:,0].nunique()<2 or f.iloc[:,1].nunique()<2: return np.nan
    if rank:f=f.rank()
    return float(f.iloc[:,0].corr(f.iloc[:,1]))


def residual_score(score,controls):
    """Cross-sectional rank OLS, fitted solely with information available at signal time."""
    frame=pd.concat([score.rename('primary'),controls],axis=1).dropna().rank(pct=True)
    result=pd.Series(np.nan,index=score.index)
    if frame.shape[1]<2 or len(frame)<max(10,3*frame.shape[1]):return result
    x=np.column_stack([np.ones(len(frame)),frame.iloc[:,1:].to_numpy()])
    y=frame.iloc[:,0].to_numpy()
    residual=y-x@np.linalg.lstsq(x,y,rcond=None)[0]
    # Numerical residual of a redundant factor is not a new signal.
    if np.std(residual)<1e-10:return result
    result.loc[frame.index]=residual
    return result


def block_interval(values,block,repeats=1000,seed=17):
    """Circular moving blocks, preserving missing slots and serial ordering."""
    x=np.asarray(values,dtype=float);n=len(x);valid=int(np.isfinite(x).sum())
    base=dict(n_dates=n,n_valid=valid,block_length=block,mean=float(np.nanmean(x)) if valid else np.nan,ci_low=np.nan,ci_high=np.nan,status='insufficient_blocks')
    if valid<5*block or n<5*block:return base
    rng=np.random.default_rng(seed)
    means=[]
    for _ in range(repeats):
        starts=rng.integers(0,n,size=math.ceil(n/block))
        ix=((starts[:,None]+np.arange(block))%n).ravel()[:n]
        sample=x[ix]
        if np.isfinite(sample).any():means.append(np.nanmean(sample))
    base.update(ci_low=float(np.quantile(means,.025)),ci_high=float(np.quantile(means,.975)),status='estimated')
    return base


def forward_label(data,i,h,delay,end):
    dates=data['close'].index;entry=i+1+delay;exit_=i+h+delay
    if exit_>=len(dates) or dates[exit_]>end:return None
    a=data['open'].iloc[entry]*data['cumadj'].iloc[entry]
    b=data['close'].iloc[exit_]*data['cumadj'].iloc[exit_]
    return (b/a-1).where(a.gt(0)&b.gt(0)).replace([np.inf,-np.inf],np.nan)


def advanced_diagnostics(data,settings,frames,status,out,progress=None):
    opts=settings.get('diagnostics',{})
    if not opts.get('enabled',False):return
    delays=opts.get('delays',[0,1,2,5]);repeats=opts.get('bootstrap_repeats',1000)
    if not isinstance(delays,list) or not delays or len(set(delays))!=len(delays) or any(type(x)!=int or not 0<=x<=60 for x in delays):raise ValueError('延迟须为0至60的不重复整数')
    if type(repeats)!=int or not 100<=repeats<=10000:raise ValueError('重采样次数须为100至10000整数')
    controls=opts.get('controls',['中期动量','低波动','成交额','趋势强度'])
    if not isinstance(controls,list) or len(set(controls))!=len(controls) or any(x not in TEMPLATES for x in controls):raise ValueError('对照因子名称无效或重复')
    refs={}
    for name in controls:
        kind,w,skip,higher=TEMPLATES[name];scope={};exec(template_source(kind),scope)
        refs[name]=(scope['factor'],dict(window=w,skip=skip),higher,max(w+skip+1,20))
    dates=data['close'].index;adj=data['close']*data['cumadj'];returns=adj.pct_change(fill_method=None)
    adv=data['amt'].rolling(20).mean();vol=returns.rolling(20).std()
    proxy=returns.median(axis=1);trend=(1+proxy).rolling(20).apply(np.prod,raw=True)-1
    proxy_vol=proxy.rolling(20).std();vol_threshold=proxy_vol.shift().rolling(252,min_periods=60).median()
    corrs=[];daily=[];strata=[];environments=[];delay_rows=[];robust=[];influences=[]
    groups=settings.get('groups',5);horizons=settings.get('horizons',[5,20,60]);sampling=settings.get('step',5)
    signal_dates=sorted(frames['scores'].date.unique())
    for number,date in enumerate(signal_dates):
        f=frames['scores'][frames['scores'].date==date].set_index('symbol');i=dates.get_loc(date)
        score=f.factor if settings.get('higher_is_better',True) else -f.factor
        ctx=FactorContext(data,i,status.at(date,data['close'].columns))
        reference=pd.DataFrame(index=f.index)
        for name,(fn,params,higher,bars) in refs.items():
            reference[name]=(fn(ctx,**params)*(1 if higher else -1)).reindex(f.index) if i+1>=bars else np.nan
        all_scores=pd.concat([score.rename('primary'),reference],axis=1)
        for a in all_scores:
            for b in all_scores:
                pair=all_scores[[a,b]] if a!=b else all_scores[[a]]
                corrs.append(dict(date=date,factor_a=a,factor_b=b,rank_correlation=correlation(all_scores[a],all_scores[b]),n_common=int(pair.dropna().shape[0])))
        residual=residual_score(score,reference) if len(reference.columns) else pd.Series(np.nan,index=score.index)
        segment=f.segment.iloc[0];end=pd.Timestamp(settings['end'])
        if settings.get('split',False) and segment!='test':end=pd.Timestamp(settings['train_end'] if segment=='train' else settings['validation_end'])
        market='up' if trend.iloc[i]>=0 else 'down'
        if pd.isna(trend.iloc[i]):market='unknown'
        risk='unknown' if pd.isna(vol_threshold.iloc[i]) else ('high' if proxy_vol.iloc[i]>=vol_threshold.iloc[i] else 'low')
        environments.append(dict(date=date,market_trend=market,market_volatility=risk,proxy_return_20=trend.iloc[i],proxy_volatility_20=proxy_vol.iloc[i],past_volatility_threshold=vol_threshold.iloc[i]))
        for h in horizons:
            label=forward_label(data,i,h,0,end)
            y=label.reindex(f.index) if label is not None else pd.Series(np.nan,index=f.index)
            top=y[f.group==groups];pool=y.mean()
            shared=residual.notna()&y.notna()
            daily.append(dict(date=date,segment=segment,horizon=h,rank_ic=correlation(score,y),residual_rank_ic=correlation(residual,y),same_sample_raw_ic=correlation(score[shared],y[shared]),residual_n=int(shared.sum()),top_minus_pool=top.mean()-pool,n_signal=len(y),n_valid=int(y.notna().sum())))
            for dimension,values in [('liquidity',adv.iloc[i]),('volatility',vol.iloc[i]),('price',data['close'].iloc[i])]:
                bins=np.ceil(values.reindex(f.index).rank(pct=True)*3).clip(1,3)
                for bucket in [1,2,3]:
                    take=bins==bucket
                    strata.append(dict(date=date,segment=segment,horizon=h,dimension=dimension,bucket=str(bucket),n_signal=int(take.sum()),n_valid=int(y[take].notna().sum()),rank_ic=correlation(score[take],y[take]),top_minus_pool=y[take & (f.group==groups)].mean()-y[take].mean()))
            for dimension,bucket in [('market_trend',market),('market_volatility',risk)]:
                strata.append(dict(date=date,segment=segment,horizon=h,dimension=dimension,bucket=bucket,n_signal=len(y),n_valid=int(y.notna().sum()),rank_ic=correlation(score,y),top_minus_pool=top.mean()-pool))
            clipped=score.clip(score.quantile(.01),score.quantile(.99))
            robust.append(dict(date=date,segment=segment,horizon=h,pearson_raw=correlation(score,y,False),pearson_winsorized_1_99=correlation(clipped,y,False),rank_ic=correlation(score,y),top_return=top.mean(),top_return_excluding_largest_abs_outcome=top.drop(top.abs().idxmax()).mean() if top.notna().sum()>1 else np.nan))
            # Ex-post influence diagnosis only; never used for factor selection or execution.
            valid_top=top.dropna()
            if len(valid_top):
                contributions=valid_top/len(valid_top)
                denominator=contributions.abs().sum()
                influences.append(dict(date=date,segment=segment,horizon=h,top_n=len(valid_top),largest_abs_contribution_fraction=contributions.abs().max()/denominator if denominator else 0.,largest_outcome_symbol=valid_top.abs().idxmax(),top_return=valid_top.mean()))
            for delay in delays:
                delayed=forward_label(data,i,h,delay,end)
                v=delayed.reindex(f.index) if delayed is not None else pd.Series(np.nan,index=f.index)
                delay_rows.append(dict(date=date,segment=segment,horizon=h,delay=delay,rank_ic=correlation(score,v),top_minus_pool=v[f.group==groups].mean()-v.mean(),n_signal=len(v),n_valid=int(v.notna().sum())))
        if progress:progress('扩展因子诊断 '+str(date)[:10],.55+.15*(number+1)/max(1,len(signal_dates)))
    tables=dict(factor_correlations=pd.DataFrame(corrs),incremental_daily=pd.DataFrame(daily),strata_daily=pd.DataFrame(strata),market_environments=pd.DataFrame(environments),delay_daily=pd.DataFrame(delay_rows),robustness_daily=pd.DataFrame(robust),influence_daily=pd.DataFrame(influences))
    for name,table in tables.items():table.to_csv(out/(name+'.csv'),index=False)
    c=tables['factor_correlations']
    c.groupby(['factor_a','factor_b']).agg(mean_rank_correlation=('rank_correlation','mean'),dates=('rank_correlation','count'),mean_common_stocks=('n_common','mean')).to_csv(out/'factor_correlation_summary.csv')
    s=tables['strata_daily']
    s.groupby(['segment','horizon','dimension','bucket']).agg(mean_rank_ic=('rank_ic','mean'),ic_dates=('rank_ic','count'),mean_top_minus_pool=('top_minus_pool','mean'),n_signal=('n_signal','sum'),n_valid=('n_valid','sum')).to_csv(out/'strata_summary.csv')
    intervals=[]
    series=tables['incremental_daily']
    requested_block=opts.get('block_length',5)
    if type(requested_block)!=int or requested_block<1:raise ValueError('时间块长度须为正整数')
    for (segment,h),g in series.groupby(['segment','horizon']):
        # Retain all sampled dates, including dates with zero eligible stocks.
        grid=frames['coverage'].loc[frames['coverage'].segment==segment,'date']
        g=g.set_index('date').reindex(grid)
        block=max(requested_block,math.ceil(h/sampling))
        for metric in ['rank_ic','residual_rank_ic','top_minus_pool']:
            intervals.append(dict(segment=segment,horizon=h,metric=metric,**block_interval(g[metric],block,repeats)))
    pd.DataFrame(intervals).to_csv(out/'confidence_intervals.csv',index=False)
    tables['delay_daily'].groupby(['segment','horizon','delay']).agg(mean_rank_ic=('rank_ic','mean'),mean_top_minus_pool=('top_minus_pool','mean'),dates=('rank_ic','count'),n_signal=('n_signal','sum'),n_valid=('n_valid','sum')).to_csv(out/'delay_summary.csv')
    series.groupby(['segment','horizon']).agg(raw_ic=('rank_ic','mean'),same_sample_raw_ic=('same_sample_raw_ic','mean'),residual_ic=('residual_rank_ic','mean'),residual_dates=('residual_rank_ic','count'),mean_residual_n=('residual_n','mean')).to_csv(out/'incremental_summary.csv')
    variants=opts.get('parameter_sets',[])
    if not isinstance(variants,list) or len(variants)>12 or any(not isinstance(v,dict) for v in variants):raise ValueError('因子参数组须为最多12个对象的列表')
    attempts=[];stability=[]
    source=(out/'factor.py').read_text()
    for j,args in enumerate([{}]+variants):
        merged={**settings.get('params',{}),**args};label='base' if j==0 else f'params_{j}'
        attempts.append(dict(label=label,params=merged,status='running'))
        (out/'factor_attempts.json').write_text(json.dumps(attempts,ensure_ascii=False,indent=2))
        try:
            result=frames if j==0 else evaluate(data,{**settings,'params':merged},source,status)
            stats=summarize_factor(result['observations']);stats['label']=label;stats['params']=json.dumps(merged)
            stability.append(stats);attempts[-1]['status']='complete'
            if j>0:result['observations'].to_csv(out/(label+'_observations.csv'),index=False)
        except Exception as exc:
            attempts[-1].update(status='failed',error=str(exc))
        (out/'factor_attempts.json').write_text(json.dumps(attempts,ensure_ascii=False,indent=2))
        if progress:progress('参数稳定性 '+label,.7+.1*(j+1)/(len(variants)+1))
    pd.concat(stability,ignore_index=True).to_csv(out/'parameter_stability.csv',index=False)
    (out/'research_usage.json').write_text(json.dumps({'historical_data_already_observed':True,'automatic_selection':False,'multiple_testing_adjusted':False,'note':opts.get('note',''),'controls':controls,'bootstrap_seed':17,'bootstrap_repeats':repeats},ensure_ascii=False,indent=2))


def export_diagnostics(out):
    """Append offline figures and tables without changing the original signal statistics."""
    import html,base64
    import matplotlib.pyplot as plt
    import markdown
    images=['factor_charts.png']
    sections=[]
    files=[('factor_correlation_summary.csv','因子相关性'),('incremental_summary.csv','控制已有因子后的增量信号'),('strata_summary.csv','分环境与分层'),('confidence_intervals.csv','95%时间块重采样区间'),('delay_summary.csv','延迟敏感性'),('parameter_stability.csv','参数稳定性'),('factor_execution_summary.csv','分组组合执行后表现')]
    for file,title in files:
        if not (out/file).exists():continue
        table=pd.read_csv(out/file)
        sections.append('## '+title+'\n\n'+markdown_table(table)+'\n')
    if (out/'factor_correlation_summary.csv').exists():
        c=pd.read_csv(out/'factor_correlation_summary.csv').pivot(index='factor_a',columns='factor_b',values='mean_rank_correlation')
        # ASCII legend avoids dependence on local CJK font installation in exports.
        labels=['F'+str(i) for i in range(len(c))]
        fig,ax=plt.subplots(figsize=(8,6));im=ax.imshow(np.ma.masked_invalid(c.to_numpy()),vmin=-1,vmax=1,cmap='RdBu_r')
        ax.set_xticks(range(len(c)),labels);ax.set_yticks(range(len(c)),labels)
        for i in range(len(c)):
            for j in range(len(c)):
                if np.isfinite(c.iloc[i,j]):ax.text(j,i,f'{c.iloc[i,j]:.2f}',ha='center',va='center')
        ax.set_title('Mean cross-sectional rank correlation');fig.colorbar(im,ax=ax);fig.tight_layout()
        fig.savefig(out/'factor_correlation.png',dpi=140);plt.close(fig);images.append('factor_correlation.png')
        sections.append('相关性图例：'+', '.join(f'{label}={name}' for label,name in zip(labels,c.index))+'\n')
        ci=pd.read_csv(out/'confidence_intervals.csv');ci=ci[ci.status=='estimated'].reset_index(drop=True)
        fig,ax=plt.subplots(figsize=(10,4))
        if len(ci):
            ax.vlines(range(len(ci)),ci.ci_low,ci.ci_high,color='#2563eb');ax.scatter(range(len(ci)),ci['mean'])
            ax.set_xticks(range(len(ci)),[f'{r.segment}/{r.horizon}/{r.metric}' for r in ci.itertuples()],rotation=40,ha='right',fontsize=8)
        else:ax.text(.5,.5,'Insufficient independent time blocks',ha='center',transform=ax.transAxes)
        ax.axhline(0,color='gray',lw=.8);ax.set_title('95% moving-block bootstrap intervals');fig.tight_layout()
        fig.savefig(out/'factor_intervals.png',dpi=140);plt.close(fig);images.append('factor_intervals.png')
        stability=pd.read_csv(out/'parameter_stability.csv')
        fig,ax=plt.subplots(figsize=(10,4))
        for (seg,h),part in stability.groupby(['segment','horizon']):ax.plot(part.label,part.ic_mean,marker='o',label=f'{seg}/{h}')
        ax.set_title('Parameter stability | mean Rank IC');ax.legend();fig.tight_layout();fig.savefig(out/'factor_stability.png',dpi=140);plt.close(fig);images.append('factor_stability.png')
    if (out/'factor_execution_summary.csv').exists():
        runs=pd.read_csv(out/'factor_execution_summary.csv');fig,ax=plt.subplots(figsize=(10,4))
        for row in runs.itertuples():
            if row.status!='complete':continue
            folder=out/row.portfolio;d=pd.read_csv(folder/'daily.csv',parse_dates=['date'])
            initial=json.loads((folder/'config.json').read_text())['engine']['initial_cash']
            ax.plot(d.date,d.equity/initial,label=row.portfolio)
        if any(runs.status=='complete'):ax.legend()
        else:ax.text(.5,.5,'All execution scenarios failed; see errors',ha='center',transform=ax.transAxes)
        ax.set_title('Weekly long-only executed portfolios | after costs');fig.tight_layout();fig.savefig(out/'factor_execution.png',dpi=140);plt.close(fig);images.append('factor_execution.png')
    limits='''## 扩展评价口径与限制

- 相关性：在主因子有效股票池内逐日截面排名相关，再对日期取均值；各对因子有效样本可能不同，见n_common。
- 增量信号：在信号日用已有因子的截面排名OLS解释主因子排名；剩余信号计算Rank IC。并列显示同样本原始IC；完全冗余或样本不足留空。不等同于因果效应，也未进行行业/市值中性化。
- 市场代理：输入股票池当日可得复权收益中位数（不按ST筛选），20日复合收益判定涨跌；20日波动率与之前最多252日、至少60个有效值的历史中位数比较。仅使用截至信号日的信息，不是正式指数。
- 股票分层：信号日20日平均成交额、20日波动率及未复权股价各分三组；同值不拆组。分层顶组差使用原全池顶组与该层交集，不在各层重新选股。报告同时列样本数。
- 延迟：固定T日信号和分组，T+1+d开盘至T+h+d收盘，持有时长不变；跨分区标签仍剔除。不同延迟有效样本可不同，不能仅凭均值差归因于执行延迟。
- 异常值诊断：原值Pearson、1%/99%截尾Pearson及Rank IC并列；剔除最大绝对结果的顶组收益仅为事后敏感性，不用于策略交易。influence_daily.csv记录极端贡献比例与证券。
- 置信区间：固定随机种子17的循环移动时间块重采样，缺失日期槽位保留；块长至少覆盖收益期限相对采样频率的重叠跨度。有效日期不足5个块则不输出区间。区间仍依赖块长与历史代表性，不是未来收益保证。
- 参数尝试：全部配置及失败记录保存在factor_attempts.json，不自动选最佳。历史均视为已观察；未进行多重检验校正，因此不得据多个试验中单一显著结果宣称发现有效因子。
- 执行组合：所选分组与同池等权各自独立资金、周度调仓；按前日初始化信号强制首日有买入，否则该情景失败，不伪造成交。分组等权且受单股上限约束。撮合使用原有T+1、近似涨跌停、历史容量、资金、费用与滑点规则。分组研究的h日收益与周度账户净值是不同对象，不能直接相减作为成本损失。
- 期末结算金额单列，若选择settle则属研究假设、不是实际成交；hold可能保留持仓。失败情景列出原因，不纳入成功情景比较。行业、市值和独立样本外检验仍未完成。
'''
    text=(out/'report.md').read_text()+'\n'+'\n'.join(sections)+'\n'+limits
    for name in images[1:]:text+=f'\n![{name}]({name})\n'
    (out/'report.md').write_text(text)
    body=markdown.markdown(html.escape(text,quote=False),extensions=['tables','fenced_code'])
    for name in images:
        body=body.replace('src="'+name+'"','src="data:image/png;base64,'+base64.b64encode((out/name).read_bytes()).decode()+'"')
    (out/'report.html').write_text('<meta charset="utf-8"><title>策演·扩展因子评价</title><style>body{max-width:1100px;margin:40px auto;font:16px system-ui;line-height:1.6}img{max-width:100%}pre{white-space:pre-wrap}table{display:block;overflow:auto;border-collapse:collapse;font-size:12px}th,td{padding:7px;border:1px solid #ddd}</style>'+body)
