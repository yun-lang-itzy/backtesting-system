"""Strategy library controls placed before editor widgets so loading is atomic in UI."""
import json
import streamlit as st
from .strategy_library import StrategyLibrary


def library_picker(root):
    library=StrategyLibrary(root/'strategy_library')
    selected=None
    with st.container(border=True):
        st.markdown('#### 策略库 · 载入 / 删除')
        if st.session_state.get('library_notice'):st.success(st.session_state.pop('library_notice'))
        items=library.list();by_id={x['id']:x for x in items}
        if items:
            identifier=st.selectbox('已保存策略',list(by_id),format_func=lambda i:by_id[i]['name'],key='library_selection')
            selected=by_id[identifier]
            st.caption(f"更新于 {selected['updated_at']} · {selected['description']}")
            left,right=st.columns(2)
            if left.button('载入所选策略（替换代码与参数）'):
                try:
                    item=library.get(identifier)
                    st.session_state.source=item['source']
                    st.session_state.main_94=json.dumps(item['params'],ensure_ascii=False,indent=2)
                    st.session_state.library_loaded_source=item['source']
                    st.session_state.library_name=item['name']
                    st.session_state.library_description=item['description']
                    st.success('已载入；下方JSON为保存的完整参数，可直接修改后回测。')
                except ValueError as e:st.error(str(e))
            if right.button('删除所选策略',help='移入本地回收站，可恢复；当前编辑代码和历史回测快照保留。'):
                try:
                    library.delete(identifier)
                    st.session_state.library_notice='已移入回收站；编辑内容和历史回测记录保留。'
                    st.rerun()
                except ValueError as e:st.error(str(e))
            with st.expander('预览已保存代码与参数'):
                st.code(selected['source'],language='python')
                st.code(json.dumps(selected['params'],ensure_ascii=False,indent=2),language='json')
        else:st.info('策略库为空。在下方编辑代码与参数后，命名保存即可反复使用。')
        with st.expander('策略回收站'):
            trash=library.list(deleted=True);deleted={x['id']:x for x in trash}
            if deleted:
                identifier=st.selectbox('已删除策略',list(deleted),format_func=lambda i:deleted[i]['name'],key='library_trash_selection')
                if st.button('恢复所选策略'):
                    try:
                        library.restore(identifier);st.session_state.library_notice='策略已恢复。';st.rerun()
                    except ValueError as e:st.error(str(e))
            else:st.caption('回收站为空。')
    return library,selected


def library_save(library,selected,source,params):
    with st.expander('保存到策略库',expanded=True):
        name=st.text_input('策略名称',key='library_name',max_chars=100)
        description=st.text_input('策略说明（可选）',key='library_description')
        st.caption('保存当前代码与实际生效的构造参数；不包含资金、费用、数据路径和回测区间。允许保存代码草稿，保存时不执行代码。')
        a,b=st.columns(2)
        create=a.button('另存为新策略',disabled=params is None)
        update=b.button('更新所选策略'+('：'+selected['name'] if selected else ''),disabled=params is None or selected is None)
        if create or update:
            try:
                identifier=library.save(name,source,params,description,selected['id'] if update else None)
                st.session_state.library_pending_selection=identifier
                st.session_state.library_notice='策略已保存：'+name.strip()
                st.rerun()
            except (ValueError,TypeError) as e:st.error(str(e))
