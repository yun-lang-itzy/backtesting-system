"""Weekly long-only factor buckets using the existing execution/account engine."""
import json
import traceback
from dataclasses import asdict
import numpy as np
import pandas as pd
from .strategy import Strategy
from .factors import FactorContext
from .config import Config
from .engine import simulate
from .report import summarize
from .evaluation import write_evaluation


class FactorGroupStrategy(Strategy):
    def __init__(self,source,settings,group,investment=.95,max_weight=1.):
        scope={};exec(compile(source,'factor.py','exec'),scope)
        self.factor=scope['factor'];self.settings=settings;self.group=group
        self.investment=investment;self.max_weight=max_weight

    def on_close(self,context):
        if not context.is_week_end:return None
        # Engine Context itself only retains past data. No forward labels are used.
        history=context._history
        state=pd.Series(context.security_status)
        ctx=FactorContext(history,len(history['close'])-1,state)
        value=self.factor(ctx,**self.settings.get('params',{}))
        if not isinstance(value,pd.Series) or not value.index.is_unique or not value.index.isin(ctx.symbols).all():raise ValueError('因子输出索引非法')
        value=pd.to_numeric(value,errors='raise').reindex(ctx.symbols).replace([np.inf,-np.inf],np.nan)
        amount=ctx.history('amt',20)
        valid=amount.gt(0).all() & amount.mean().ge(self.settings.get('min_adv',50_000_000)) & ctx.history('adjusted_close',1).iloc[-1].gt(0)
        valid &= ~state.isin(['ST','*ST','EXCLUDE'])
        if context.unknown_status_policy=='block':valid &= state.eq('NORMAL')
        value=value[valid & value.notna()]
        oriented=value if self.settings.get('higher_is_better',True) else -value
        if self.group:
            group=np.ceil(oriented.rank(method='average',pct=True)*self.settings.get('groups',5))
            value=value[group==self.group]
        return {symbol:min(self.investment/len(value),self.max_weight) for symbol in value.sort_index().index}


def run_group_execution(data,settings,source,status,out,audit,progress=None):
    opts=settings.get('execution',{})
    if not opts.get('enabled',False):return
    groups=opts.get('groups',[1,settings.get('groups',5)])
    if not isinstance(groups,list) or not groups or any(type(g)!=int or not 1<=g<=settings.get('groups',5) for g in groups):raise ValueError('执行分组编号无效')
    groups=list(dict.fromkeys(groups))+[0]
    config=Config(**{**opts.get('engine',{}),'entry_mode':'first_open'})
    for k,v in asdict(config).items():
        if k in ('entry_mode','terminal_mode'):continue
        if isinstance(v,bool) or not isinstance(v,(int,float)) or not np.isfinite(v) or v<0:raise ValueError('执行参数无效：'+k)
    if config.initial_cash<=0 or not 0<config.participation<=1 or type(config.lookback)!=int or config.lookback<1:raise ValueError('执行资金、参与率或窗口无效')
    investment=opts.get('investment',.95);cap=opts.get('max_weight',1.)
    if not np.isfinite(investment) or not 0<investment<=1 or not np.isfinite(cap) or not 0<cap<=1:raise ValueError('执行仓位和单股上限须在(0,1]')
    rows=[]
    for j,g in enumerate(groups):
        label=f'group_{g}' if g else 'pool_equal'
        folder=out/label;folder.mkdir()
        cfg={**settings,'engine':asdict(config),'strategy_params':{'group':g,'investment':investment,'max_weight':cap}}
        (folder/'config.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2))
        (folder/'factor.py').write_text(source)
        (folder/'data_audit.json').write_text(json.dumps(audit,indent=2))
        (folder/'status.json').write_text('{"status":"running"}')
        if progress:progress('真实撮合 '+label,.8+.15*j/len(groups))
        try:
            result=simulate(data,config,FactorGroupStrategy(source,settings,g,investment,cap),pd.Timestamp(settings['start']),pd.Timestamp(settings['end']),status_filter=status,progress=(lambda date,f:progress('真实撮合 '+label+' '+date,.8+.15*(j+f)/len(groups))) if progress else None)
            for name,table in result.items():table.to_csv(folder/(name+'.csv'),index=False)
            stats=summarize(result,config)
            (folder/'summary.json').write_text(json.dumps(stats,indent=2,allow_nan=False))
            m,_,_=write_evaluation(folder,folder)
            rows.append(dict(portfolio=label,status='complete',error='',**m))
            (folder/'status.json').write_text('{"status":"complete"}')
        except Exception as exc:
            rows.append(dict(portfolio=label,status='failed',error=str(exc)))
            (folder/'status.json').write_text('{"status":"failed"}')
            (folder/'error.txt').write_text(traceback.format_exc())
        pd.DataFrame(rows).to_csv(out/'factor_execution_summary.csv',index=False)
