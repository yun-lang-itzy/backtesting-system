"""CLI: python factor_run.py --config factor-config.json --factor factor.py"""
import argparse
import json
from pathlib import Path
from ashare.factors import run_factor
if __name__=='__main__':
    parser=argparse.ArgumentParser(description='策演因子评价')
    parser.add_argument('--config',type=Path,required=True)
    parser.add_argument('--factor',type=Path,required=True)
    parser.add_argument('--output',type=Path,default=Path(__file__).parent/'factor_runs')
    args=parser.parse_args()
    print(run_factor(json.loads(args.config.read_text()),args.factor.read_text(),args.output)[0])
