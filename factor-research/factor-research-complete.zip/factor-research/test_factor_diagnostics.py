import json
import tempfile
import unittest
from pathlib import Path
import numpy as np
import pandas as pd
from ashare.factors import evaluate,template_source,run_factor
from ashare.factor_diagnostics import block_interval, residual_score, forward_label,advanced_diagnostics
from ashare.factor_execution import run_group_execution,FactorGroupStrategy
from ashare.universe import StatusFilter
from ashare.strategy import Context

class DiagnosticsTests(unittest.TestCase):
    def fixture(self):
        rng=np.random.default_rng(42);dates=pd.bdate_range('2024-01-01',periods=220)
        returns=rng.normal(.0005,.009,(220,30))
        close=pd.DataFrame(10*np.exp(returns.cumsum(axis=0)),index=dates,columns=[f'{i:06d}.SZ' for i in range(1,31)])
        amount=pd.DataFrame(np.tile(np.linspace(1e8,3e8,30),(220,1)),index=dates,columns=close.columns)
        return dict(close=close,open=close*.999,high=close*1.05,low=close*.95,cumadj=close*0+1,amt=amount,num_trades=close*0+100)

    def settings(self,data):
        return dict(start=str(data['close'].index[130]),end=str(data['close'].index[-1]),params={'window':20,'skip':0},horizons=[5,20],groups=5,step=5,min_adv=0,unknown_status_policy='allow',diagnostics=dict(enabled=True,controls=['低波动','成交额'],delays=[0,2],bootstrap_repeats=100,block_length=1,parameter_sets=[{'window':15},{'window':9999}]))

    def test_block_bootstrap_reproducible_and_insufficient(self):
        x=np.sin(np.arange(100))
        a=block_interval(x,5,100);b=block_interval(x,5,100)
        self.assertEqual(a,b);self.assertEqual(a['status'],'estimated')
        self.assertLess(a['ci_low'],a['ci_high'])
        self.assertEqual(block_interval(x[:20],5,100)['status'],'insufficient_blocks')
        gaps=x.copy();gaps[::2]=np.nan
        self.assertEqual(block_interval(gaps,5,100)['n_dates'],100)

    def test_redundant_control_and_novel_residual(self):
        x=pd.Series(np.arange(30),dtype=float)
        self.assertTrue(residual_score(x,pd.DataFrame({'same':x})).isna().all())
        y=pd.Series(np.sin(np.arange(30)))
        self.assertTrue(residual_score(y,pd.DataFrame({'other':x})).notna().all())

    def test_delay_preserves_duration_and_purges(self):
        d=self.fixture();dates=d['close'].index
        r=forward_label(d,130,5,2,dates[-1])
        pd.testing.assert_series_equal(r,d['close'].iloc[137]/d['open'].iloc[133]-1)
        self.assertIsNone(forward_label(d,130,5,2,dates[136]))

    def test_full_report_and_failed_parameter_attempt(self):
        d=self.fixture();s=self.settings(d)
        s['execution']=dict(enabled=True,groups=[1,5],investment=.95,max_weight=.2,engine={'initial_cash':1e6,'participation':.001,'terminal_mode':'settle'})
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            for name,f in d.items():f.rename_axis('date').reset_index().to_feather(root/(name+'.feather'))
            s['data']=str(root)
            out,_,_=run_factor(s,template_source('momentum'),root/'runs')
            attempts=json.loads((out/'factor_attempts.json').read_text())
            self.assertEqual([a['status'] for a in attempts],['complete','complete','failed'])
            self.assertTrue((out/'confidence_intervals.csv').exists())
            self.assertTrue((out/'factor_execution.png').exists())
            summary=pd.read_csv(out/'factor_execution_summary.csv')
            self.assertEqual(summary.status.tolist(),['complete']*3)
            self.assertTrue((summary.final_stock_value==0).all())
            self.assertTrue((summary.hypothetical_settlement_value>=0).all())
            normal=pd.read_csv(out/'group_5/trades.csv',parse_dates=['date','signal_date'])
            normal=normal[normal.execution_type=='simulated_fill']
            self.assertTrue((normal.date>normal.signal_date).all())
            self.assertIn('data:image/png;base64',(out/'report.html').read_text())
            self.assertIn('扩展评价口径',(out/'report.html').read_text())
            intervals=pd.read_csv(out/'confidence_intervals.csv')
            self.assertTrue((intervals.loc[intervals.horizon==20,'block_length']>=4).all())

    def test_market_environment_and_correlations_future_invariant(self):
        d=self.fixture();s=self.settings(d);s['diagnostics']['parameter_sets']=[]
        sf=StatusFilter(unknown_policy='allow');source=template_source('momentum')
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);a=root/'a';b=root/'b';a.mkdir();b.mkdir()
            (a/'factor.py').write_text(source);(b/'factor.py').write_text(source)
            frames=evaluate(d,s,source,sf);advanced_diagnostics(d,s,frames,sf,a)
            cutoff=d['close'].index[180];d['close'].iloc[180:]*=2
            frames=evaluate(d,s,source,sf);advanced_diagnostics(d,s,frames,sf,b)
            for file in ['market_environments.csv','factor_correlations.csv']:
                x=pd.read_csv(a/file,parse_dates=['date']);y=pd.read_csv(b/file,parse_dates=['date'])
                pd.testing.assert_frame_equal(x[x.date<cutoff],y[y.date<cutoff])

    def test_execution_status_first_filter_and_failed_group(self):
        d=self.fixture();s=self.settings(d);ctx=Context(d,134,1e6,1e6,{})
        ctx.is_week_end=True;ctx.security_status={c:'NORMAL' for c in ctx.symbols};ctx.security_status['000001.SZ']='ST'
        strategy=FactorGroupStrategy(template_source('momentum'),s,0)
        self.assertNotIn('000001.SZ',strategy.on_close(ctx))
        constant="def factor(context, **params):\n    return context.history('cumadj',1).iloc[-1]"
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);s['execution']=dict(enabled=True,groups=[1,5],engine={'initial_cash':1e6})
            run_group_execution(d,s,constant,StatusFilter(unknown_policy='allow'),root,{})
            rows=pd.read_csv(root/'factor_execution_summary.csv')
            self.assertEqual(rows.status.tolist(),['failed','failed','complete'])
