# 策演 · 因子研究

独立研究工作台及个人研究成果归档。包含共享回测引擎，便于把因子分组接入成交约束。此目录为 2026-10-24 发布快照，根目录原有回测系统保持原样。

## 研究成果

| 样例 | 范围 | 报告 |
| --- | --- | --- |
| 中期动量基础评价 | 2025 年一季度、全市场筛选、12 个采样日 | [Markdown](reports/20261023-200528-059f0442/report.md) · [离线 HTML](reports/20261023-200528-059f0442/report.html) |
| 中期动量扩展诊断 | 2025 年、固定代码排序前 200 只沪深股票、49 个采样日 | [Markdown](reports/20261023-202515-591ffb02/report.md) · [离线 HTML](reports/20261023-202515-591ffb02/report.html) |

报告目录保留因子评分、分组收益、RankIC、覆盖率、年度统计、图表、参数尝试和数据哈希。第二个样例还包括相关性、增量信号、环境与分层分析、延迟入场、异常值影响、时间块置信区间，以及 group_1、group_5、pool_equal 的模拟订单、成交、持仓与账户账本。这些均为历史模拟研究结果，不是真实账户交易。

上述样例是功能联调，不能视为因子有效性或样本外能力的证明。全市场与固定 200 只股票样本不可直接比较。历史报告保持运行时口径；当前代码存在后续界面及呈现更新，运行时源码哈希不一定等于此快照。

## 运行

在仓库根目录执行：

```bash
cd factor-research
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m streamlit run app.py --server.port 8502
```

在左侧选择“因子研究”。填写自己的行情目录、历史 ST 清单与评价参数。数据必须自行提供；本目录不含行情矩阵和真实 ST 明细，也不含 ST 获取代码。

命令行：

```bash
python factor_run.py --config factor.config.example.json --factor factors/momentum.py
python -m unittest discover -p 'test_*.py'
```

先编辑配置中的 `data` 和 `exclusions`。默认 `data/feathers` 放七个 Feather 文件，`data/exclusions.csv` 放已有历史状态。未知日期标记 UNKNOWN；默认研究配置禁止未知状态参与。复跑历史样例可用其 `reports/<运行编号>/config.json`，须自行提供匹配哈希的数据与 ST 文件。新结果写入 factor_runs，不覆盖已发布报告。

## 方法边界

- 信号只能读取截至 T 日的数据；标签为 T+1 开盘至 T+h 收盘的复权收益。跨分区标签剔除。
- 基础分组收益不含交易成本，重叠期限收益不得直接复利成账户净值。
- 扩展执行采用周度调仓独立账户，计费用、滑点、T+1、方向及容量约束；样例期末保留持仓。
- 缺少历史行业、市值与完整交易状态；排名残差不是行业/市值中性化。日线撮合与复权单位记账采用研究假设。
- 参数尝试及已观察历史明确记录，不自动选择“最佳因子”。时间块区间不代表已做多重检验校正。

## 文件入口

- `ashare/factors.py`：时间隔离、标签、分组与基础报告。
- `ashare/factor_diagnostics.py`：扩展诊断与参数研究。
- `ashare/factor_execution.py`：分组撮合模拟。
- `ashare/research_ui.py`：因子研究、策略评价与实验比较界面。
- `factors/`：自定义因子起点；`factor.config.example.json`：配置示例。
- [完整工作台说明](WORKBENCH.md) · [发布核验](VERIFICATION.md) · [文件哈希与脱敏清单](publication_manifest.json)。

公开副本仅将本机数据路径替换为通用相对路径。数值、图表和账本不改写；原始运行目录保留在本机。HTML 请下载后本地打开，GitHub 文件页不会直接执行页面。
