import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from ashare.strategy_library import StrategyLibrary

class LibraryTests(unittest.TestCase):
    def test_roundtrip_update_delete_restore(self):
        with tempfile.TemporaryDirectory() as tmp:
            lib=StrategyLibrary(Path(tmp)/'library')
            i=lib.save('周度策略','not valid Python: draft',{'top_n':50,'investment':.8},'说明')
            self.assertEqual(StrategyLibrary(lib.root).get(i)['params']['top_n'],50)
            created=lib.get(i)['created_at']
            lib.save('更新名字','raise RuntimeError("must not execute")',{'top_n':100},identifier=i)
            self.assertEqual(lib.get(i)['created_at'],created)
            lib.delete(i);self.assertEqual(lib.list(),[])
            with self.assertRaises(ValueError):lib.get(i)
            self.assertEqual(lib.list(deleted=True)[0]['id'],i)
            lib.restore(i);self.assertEqual(lib.get(i)['name'],'更新名字')

    def test_names_and_conflicts_are_not_paths(self):
        with tempfile.TemporaryDirectory() as tmp:
            lib=StrategyLibrary(tmp)
            a=lib.save('../模型','source',{})
            b=lib.save('Alpha','code',{})
            with self.assertRaises(ValueError):lib.save(' alpha ','other',{})
            with self.assertRaises(ValueError):lib.save('Alpha','other',{},identifier=a)
            self.assertEqual(lib.get(a)['source'],'source')
            lib.delete(b);c=lib.save('ALPHA','new',{})
            with self.assertRaises(ValueError):lib.restore(b)
            self.assertEqual(lib.get(c)['source'],'new')
            with self.assertRaises(ValueError):lib.save(' ','source',{})
            with self.assertRaises(ValueError):lib.save('invalid','source',{'x':float('nan')})
            with self.assertRaises(ValueError):lib.delete('../../outside')
            self.assertEqual([p.name for p in Path(tmp).iterdir()],['strategies.sqlite3'])

    def test_ui_save_load_update_delete_and_restore(self):
        from streamlit.testing.v1 import AppTest
        import ashare.library_ui
        with tempfile.TemporaryDirectory() as tmp:
            library=StrategyLibrary(tmp)
            with patch.object(ashare.library_ui,'StrategyLibrary',return_value=library):
                app=AppTest.from_file(str(Path(__file__).with_name('app.py')),default_timeout=10).run()
                def button(label):return next(x for x in app.button if x.label==label)
                def area(label):return next(x for x in app.text_area if x.label==label)
                next(x for x in app.selectbox if x.label=='持股数量').select(50).run()
                area('策略构造参数 JSON').set_value('{"investment":0.7}').run()
                source=area('Python 策略代码').value
                next(x for x in app.text_input if x.label=='策略名称').set_value('我的周度策略').run()
                button('另存为新策略').click().run()
                self.assertFalse(app.exception)
                item=library.list()[0]
                self.assertEqual(item['params']['top_n'],50)
                self.assertEqual(item['params']['investment'],.7)
                area('Python 策略代码').set_value('# changed').run()
                button('载入所选策略（替换代码与参数）').click().run()
                self.assertFalse(app.exception)
                self.assertEqual(area('Python 策略代码').value,source)
                self.assertEqual(json.loads(area('策略构造参数 JSON').value),item['params'])
                self.assertFalse(any(x.label=='持股数量' for x in app.selectbox))
                area('策略构造参数 JSON').set_value('{"top_n":100}').run()
                button('更新所选策略：我的周度策略').click().run()
                self.assertEqual(library.get(item['id'])['params'],{'top_n':100})
                button('删除所选策略').click().run()
                self.assertFalse(app.exception)
                self.assertFalse(library.list())
                self.assertEqual(area('Python 策略代码').value,source)
                button('恢复所选策略').click().run()
                self.assertEqual(len(library.list()),1)
                button('载入所选模板（替换编辑区）').click().run()
                self.assertEqual(area('策略构造参数 JSON').value,'{}')
                self.assertTrue(any(x.label=='持股数量' for x in app.selectbox))
                self.assertFalse(app.exception)
