import json
import tempfile
import unittest
from pathlib import Path
import numpy as np
import pandas as pd
from ashare.factors import evaluate, template_source, summarize_factor, run_factor
from ashare.universe import StatusFilter
from ashare.evaluation import evaluate_strategy, compare_runs

class FactorTests(unittest.TestCase):
    def fixture(self):
        dates=pd.bdate_range('2024-01-01',periods=90)
        prices=pd.DataFrame({f'{i:06d}.SZ':10*(1+i*.001)**np.arange(90) for i in range(1,11)},index=dates)
        return dict(open=prices.copy(),high=prices*1.01,low=prices*.99,close=prices.copy(),cumadj=prices*0+1,amt=prices*0+1e8,num_trades=prices*0+100)

    def settings(self,d):
        return dict(start=str(d['close'].index[30]),end=str(d['close'].index[-1]),params=dict(window=10,skip=0),horizons=[1,5],step=1,groups=5,min_adv=0,unknown_status_policy='allow')

    def test_label_timing_direction_and_future_invariance(self):
        d=self.fixture();s=self.settings(d)
        result=evaluate(d,s,template_source('momentum'))
        first=result['observations'].iloc[0]
        self.assertAlmostEqual(first.mean_return,0.) # equal next open/close for h=1
        row=result['observations'].query('horizon==5 and group==0').iloc[0]
        self.assertAlmostEqual(row.rank_ic,1.)
        before=result['scores']
        d['close'].iloc[50:]*=3
        after=evaluate(d,s,template_source('momentum'))['scores']
        pd.testing.assert_frame_equal(before[before.date<d['close'].index[50]],after[after.date<d['close'].index[50]])
        s['higher_is_better']=False
        reversed_result=evaluate(self.fixture(),s,template_source('momentum'))
        self.assertAlmostEqual(reversed_result['observations'].query('horizon==5 and group==0').iloc[0].rank_ic,-1.)

    def test_status_and_split_and_missing_labels(self):
        d=self.fixture();s=self.settings(d);s.update(split=True,train_end=str(d['close'].index[45]),validation_end=str(d['close'].index[65]))
        status=StatusFilter(unknown_policy='block')
        status.rows=pd.DataFrame([dict(symbol=c,start_date=d['close'].index[0],end_date=d['close'].index[-1],known_date=d['close'].index[0],status='ST' if i==0 else 'NORMAL') for i,c in enumerate(d['close'].columns)])
        out=evaluate(d,s,template_source('momentum'),status)
        self.assertNotIn('000001.SZ',out['scores'].symbol.values)
        purged=out['observations'].query("segment=='train' and horizon==5 and label_status=='purged_boundary'")
        self.assertEqual(len(purged),5)
        d['close'].iloc[35,9]=np.nan
        out=evaluate(d,s,template_source('momentum'),status)
        row=out['observations'].query('horizon==5 and group==0').iloc[0]
        self.assertEqual(row.n_signal,9);self.assertEqual(row.n_valid,8)
        summary=summarize_factor(out['observations'])
        self.assertTrue((summary.label_coverage<1).any())

    def test_constant_and_unknown(self):
        d=self.fixture();s=self.settings(d)
        source="def factor(context, **params):\n    return context.history('cumadj',1).iloc[-1]"
        out=evaluate(d,s,source)
        self.assertTrue(out['observations'].rank_ic.isna().all())
        self.assertEqual(out['scores'].group.nunique(),1)
        s['unknown_status_policy']='block'
        out=evaluate(d,s,source)
        self.assertEqual(out['coverage'].factor_valid.sum(),0)
        self.assertEqual(out['coverage'].unknown.iloc[0],10)

    def test_context_no_future_and_invalid_output(self):
        d=self.fixture();s=self.settings(d)
        source="def factor(context, **params):\n    assert context.history('close',2).index[-1] == context.date\n    assert all(f.index[-1] == context.date for f in context._past.values())\n    return context.history('close',2).iloc[-1]"
        evaluate(d,s,source)
        with self.assertRaises(ValueError):evaluate(d,s,'def factor(context, **params):\n    return {}')

    def test_archived_factor_report(self):
        d=self.fixture();s=self.settings(d)
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            for k,f in d.items():f.rename_axis('date').reset_index().to_feather(root/(k+'.feather'))
            s['data']=str(root)
            out,_,_=run_factor(s,template_source('momentum'),root/'runs')
            self.assertEqual(json.loads((out/'status.json').read_text())['status'],'complete')
            self.assertIn('data:image/png;base64', (out/'report.html').read_text())
            self.assertTrue((out/'data_audit.json').exists())

class StrategyEvaluationTests(unittest.TestCase):
    def archive(self,root):
        root.mkdir(exist_ok=True)
        dates=pd.bdate_range('2025-01-02',periods=4)
        pd.DataFrame(dict(date=dates,equity=[90,80,100,95],cash=[45,40,50,95],market_value=[45,40,50,0],fees=[0,0,0,0],slippage_cost=[0,0,0,0],stale_value=[0,0,0,0])).to_csv(root/'daily.csv',index=False)
        pd.DataFrame([dict(side='buy',status='partial_capacity_or_cash',requested_units=10,filled_units=5,requested_value_at_signal=100,filled_notional=50),dict(side='sell',status='hypothetical_settlement',requested_units=5,filled_units=5,requested_value_at_signal=95,filled_notional=95)]).to_csv(root/'orders.csv',index=False)
        (root/'config.json').write_text(json.dumps(dict(start=str(dates[0]),end=str(dates[-1]),engine=dict(initial_cash=100))))
        (root/'data_audit.json').write_text(json.dumps(dict(close=dict(sha256='abc'),source_hashes={'engine.py':'same'})))
        (root/'status.json').write_text('{"status":"complete"}')
        return dates

    def test_recovery_settlement_and_missing_targets(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp); dates=self.archive(p)
            m,exposure,_=evaluate_strategy(p)
            self.assertEqual(m['longest_underwater_sessions'],2)
            self.assertEqual(m['recovery_date'],str(dates[2].date()))
            self.assertEqual(m['normal_value_fill_ratio'],.5)
            self.assertEqual(m['hypothetical_settlement_value'],95)
            self.assertIsNone(m['average_target_stock_weight'])
            pd.DataFrame(dict(date=[dates[0]-pd.Timedelta(days=1),dates[1]],target_weight=[.95,0])).to_csv(p/'targets.csv',index=False)
            m,e,_=evaluate_strategy(p)
            self.assertEqual(e.target_stock_weight.tolist(),[.95,.95,0,0])

    def test_comparison_detects_contract_changes(self):
        with tempfile.TemporaryDirectory() as tmp:
            a,b=Path(tmp)/'a',Path(tmp)/'b'
            self.archive(a);self.archive(b)
            _,diff,_=compare_runs([a,b]);self.assertEqual(diff,[])
            cfg=json.loads((b/'config.json').read_text());cfg['engine']['initial_cash']=1000
            (b/'config.json').write_text(json.dumps(cfg))
            _,diff,_=compare_runs([a,b]);self.assertIn('engine',diff)

    def test_ui_research_navigation(self):
        from streamlit.testing.v1 import AppTest
        app=AppTest.from_file(str(Path(__file__).with_name('app.py'))).run()
        for page in ['因子研究','策略评价','实验对比','策略开发与回测']:
            app.radio[0].set_value(page).run()
            self.assertFalse(app.exception)

class IntegrationTests(unittest.TestCase):
    def test_runner_target_report_and_capital_rerun(self):
        from ashare.runner import run
        from test_backtest import BacktestTests
        d=BacktestTests().fixture()
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            for k,f in d.items():f.rename_axis('date').reset_index().to_feather(root/(k+'.feather'))
            settings=dict(data=str(root),start='2024-02-01',end='2024-03-01',engine={'initial_cash':1000000,'terminal_mode':'settle'},equal_weight_comparison=False,research={'capital_multipliers':[.1,10]})
            source="from ashare import Strategy\nclass UserStrategy(Strategy):\n def on_close(self,c): return {'000001.SZ':.5} if c.is_week_end else None"
            out,result,_=run(settings,source,root/'runs')
            self.assertTrue((out/'strategy_evaluation.json').exists())
            self.assertTrue((out/'targets.csv').exists())
            self.assertIn('策略评价',(out/'report.html').read_text())
            e=pd.read_csv(out/'exposure_evaluation.csv')
            self.assertEqual(e.target_stock_weight.iloc[0],.5)
            self.assertEqual(e.target_stock_weight.iloc[-1],0)
            attempts=json.loads((out/'attempts.json').read_text())['attempts']
            self.assertEqual([a['engine']['initial_cash'] for a in attempts],[100000,10000000])
            self.assertTrue(all((out/(a['label']+'_daily.csv')).exists() for a in attempts))

    def test_editor_survives_navigation(self):
        from streamlit.testing.v1 import AppTest
        app=AppTest.from_file(str(Path(__file__).with_name('app.py'))).run()
        editor=next(x for x in app.text_area if x.label=='Python 策略代码')
        editor.set_value('# custom draft\n'+editor.value).run()
        original=app.session_state['source']
        app.radio[0].set_value('因子研究').run()
        app.radio[0].set_value('策略开发与回测').run()
        self.assertEqual(app.session_state['source'],original)
        self.assertFalse(app.exception)
